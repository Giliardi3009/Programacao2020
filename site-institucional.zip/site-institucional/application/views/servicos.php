<?php $this->load->view('commons/header') ?>
<div class="container">
	<div class="page-header">
		<h1>Serviços</h1>
	</div>
	<p class="lead">Esses são os serviços que a empresa oferece, e a página é composta por cabeçalho, rodapé e conteúdo tendo título e parágrafos.</p>
	<div class="row">
		<div class="col-lg-4">
			<h3>Serviço 1</h3>
			<p>Descrição do serviço</p>
			<p><a class="btn btn-primary" href="#" role="button">Detalhes &raquo;</a></p>
		</div>
		<div class="col-lg-4">
			<h3>Serviço 2</h3>
			<p>Descrição do serviço</p>
			<p><a class="btn btn-primary" href="#" role="button">Detalhes &raquo;</a></p>
		</div>
		<div class="col-lg-4">
			<h3>Serviço 3</h3>
			<p>Descrição do serviço</p>
			<p><a class="btn btn-primary" href="#" role="button">Detalhes &raquo;</a></p>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-4">
			<h3>Serviço 4</h3>
			<p>Descrição do serviço</p>
			<p><a class="btn btn-primary" href="#" role="button">Detalhes &raquo;</a></p>
		</div>
		<div class="col-lg-4">
			<h3>Serviço 5</h3>
			<p>Descrição do serviço</p>
			<p><a class="btn btn-primary" href="#" role="button">Detalhes &raquo;</a></p>
		</div>
		<div class="col-lg-4">
			<h3>Serviço 6</h3>
			<p>Descrição do serviço</p>
			<p><a class="btn btn-primary" href="#" role="button">Detalhes &raquo;</a></p>
		</div>
	</div>
</div>
<?php $this->load->view('commons/footer') ?>
